
# Enable-Teams-AutoStart-Intune.ps1

## Overview
This PowerShell script is designed to be deployed via Microsoft Intune to ensure that Microsoft Teams automatically starts when any user signs into Windows. It uses the HKLM Run registry key so the setting applies to all users on the machine.

## What It Does
- Checks if Teams is installed at: C:\Program Files (x86)\Teams Installer\Teams.exe
- If found, adds a registry entry to auto-start Teams on login
- Creates a log file of all actions at: C:\ProgramData\TeamsAutoStart\setup.log
- Handles missing paths, registry errors, and unexpected issues gracefully

## How to Use
1. Upload this script to Intune:
   - Go to **Devices > Scripts > Add > PowerShell**
2. Configure it to:
   - **Run script in system context:** Yes
   - **Assign** to target **device groups**
3. Monitor script execution via Intune logs or check the log file on the device

## Notes
- This script assumes Teams is deployed using the machine-wide installer.
- The Teams auto-start entry is placed in `HKLM\Software\Microsoft\Windows\CurrentVersion\Run`.

## Contact
Maintainer: Harshaa Vardhan  
Tool: [M365Advisor](https://m365advisor.us)
